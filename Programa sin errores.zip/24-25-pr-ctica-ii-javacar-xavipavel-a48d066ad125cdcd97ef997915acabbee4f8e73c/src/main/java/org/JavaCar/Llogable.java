package org.JavaCar;

public interface Llogable {
    double calcularPreu(int dies);
}
